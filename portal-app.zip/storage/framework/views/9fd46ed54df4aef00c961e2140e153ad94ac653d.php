<?php $__env->startSection('content'); ?>
    <div class="hk-pg-wrapper">
        <!-- Container -->
        <div class="container-fluid mt-xl-50 mt-sm-30 mt-15">
            <section class="hk-sec-wrapper">
                <h5 class="hk-sec-title">Add Organization</h5>
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-inv alert-inv-danger" role="alert">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-sm">
                        <form action="<?php echo e(route('admin.store_org')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" class="form-control mt-15" placeholder="Organization Name" name="org_name" required>
                                </div>
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-primary mt-15">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
            <section class="hk-sec-wrapper">
                <h5 class="hk-sec-title">Organization lists & Download Directory</h5>
                <div class="row">
                    <div class="col-sm">
                        <div class="table-wrap">
                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Organization Name</th>
                                        <th>Directory</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php ($no = 0); ?>
                                    <?php $__currentLoopData = $orgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php ($no++); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($no); ?></th>
                                            <td><?php echo e($org->org_name); ?></td>
                                            <td><?php echo e($org->org_name); ?></td>
                                            <td><a href="<?php echo e(route('admin.delete_org', $org->id)); ?>"><span class="badge badge-danger">Delete</span></a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <!-- Footer -->
        <div class="hk-footer-wrap container">
            <footer class="footer">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <p>Design by<a href="#" class="text-dark" >WEB developer</a> © <?php echo e(date('Y')); ?></p>
                    </div>
                </div>
            </footer>
        </div>
        <!-- /Footer -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SR\LARAVEL\Portal site\portal-app\resources\views/admin/add_org.blade.php ENDPATH**/ ?>