<?php $__env->startSection('content'); ?>
    <div class="hk-pg-wrapper">
        <!-- Container -->
        <div class="container-fluid mt-xl-50 mt-sm-30 mt-15">
            <section class="hk-sec-wrapper">
                <h5 class="hk-sec-title">Licensed Products</h5>
            </section>
        </div>
        <!-- /Container -->
        <section class="hk-sec-wrapper">
            <div class="row">
                <div class="col-sm">
                    <div class="table-wrap">
                        <div class="table-responsive">
                            <table class="table mb-0">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Software Name</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php ($no = 0); ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php ($no++); ?>
                                    <?php for($i=0;$i<count($product);$i++): ?>
                                        <tr>
                                            <th scope="row"><?php echo e($no); ?></th>
                                            <td><?php echo e($product[$i]->licensed_pn); ?></td>
                                            <td><a href="<?php echo e(asset('download/'.$product[$i]->org_name.'/'.$product[$i]->licensed_pn)); ?>" class="btn btn-success" download="true">Download</a></td>
                                        </tr>
                                    <?php endfor; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Footer -->
        <div class="hk-footer-wrap container">
            <footer class="footer">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <p>Design by<a href="#" class="text-dark">WEB developer</a> © <?php echo e(date('Y')); ?></p>
                    </div>
                </div>
            </footer>
        </div>
        <!-- /Footer -->
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SR\LARAVEL\Portal site\portal-app\resources\views/user/dashboard.blade.php ENDPATH**/ ?>