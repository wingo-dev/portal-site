<?php $__env->startSection('content'); ?>
    <div class="hk-pg-wrapper">
        <!-- Container -->
        <div class="container-fluid mt-xl-50 mt-sm-30 mt-15">
            <section class="hk-sec-wrapper">
                <h1 class="hk-sec-title">Product Detail</h1>
                <div class="">
                    <h5 class="card-title">Product Name</h5>
                    <?php echo e($product[0]->licensed_pn); ?>

                    <h5 class="card-title">Description</h5>
                    <p><?php echo e($product[0]->description); ?></p>
                    <h5 class="card-title">Product Patch</h5>
                    <p></p>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SR\LARAVEL\Portal site\portal-app\resources\views/admin/product_detail.blade.php ENDPATH**/ ?>