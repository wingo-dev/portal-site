<?php $__env->startSection('content'); ?>
    <div class="hk-pg-wrapper">
        <!-- Container -->
        <div class="container-fluid mt-xl-50 mt-sm-30 mt-15">
            <section class="hk-sec-wrapper">
                <h5 class="hk-sec-title">Add Product</h5>
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-inv alert-inv-danger" role="alert">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-sm">
                        <form action="<?php echo e(route('admin.store_product')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="file" class="form-control mt-15" name="product_file" required>
                                </div>
                                <div class="col-md-6">
                                    <select class="form-control custom-select  mt-15" name="org" required>
                                        <option selected>Select Group</option>
                                        <?php $__currentLoopData = $orgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($org->id); ?>"><?php echo e($org->org_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <textarea class="form-control mt-15" name="product_description" placeholder="Product description"></textarea>
                                </div>
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-primary mt-15">upload</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
            <section class="hk-sec-wrapper">
                <h5 class="hk-sec-title">Download directory & uploaded files</h5>
                <div class="row">
                    <div class="col-sm">
                        <div class="table-wrap">
                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Organization Name</th>
                                        <th>Uploaded files</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php ($no = 0); ?>
                                    <?php $__currentLoopData = $uploadedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php for($i = 0; $i<count($product); $i++): ?>
                                            <?php ($no++); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($no); ?></th>
                                            <?php if($i == 0): ?>
                                                <td><?php echo e($product[$i]->org_name); ?></td>
                                            <?php else: ?>
                                                <td></td>
                                            <?php endif; ?>
                                                <td><a href="<?php echo e(route('admin.product_detail', $product[$i]->product_id)); ?>"><?php echo e($product[$i]->licensed_pn); ?></a></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.delete_product', $product[$i]->product_id)); ?>"><span class="badge badge-danger">Delete</span></a>
                                            </td>
                                        </tr>
                                        <?php endfor; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <!-- Footer -->
        <div class="hk-footer-wrap container">
            <footer class="footer">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <p>Design by<a href="#" class="text-dark">WEB developer</a> © <?php echo e(date('Y')); ?></p>
                    </div>
                </div>
            </footer>
        </div>
        <!-- /Footer -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SR\LARAVEL\Portal site\portal-app\resources\views/admin/add_product.blade.php ENDPATH**/ ?>