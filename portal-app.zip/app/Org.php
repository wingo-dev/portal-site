<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Org extends Model
{
    //
}
